"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getFeedbackStats = exports.updateFeedbackStatus = exports.getFeedbackDetail = exports.respondToFeedback = exports.getAllFeedbacks = exports.getUserFeedbacks = exports.createFeedback = void 0;
const database_1 = require("../utils/database");
const ulid_1 = require("ulid");
const socket_1 = require("../utils/socket");
const createFeedback = async (req, res) => {
    try {
        console.log('createFeedback called with body:', req.body);
        const { type, subject, message, priority } = req.body;
        const userId = req.user?.id;
        if (!userId) {
            return res.status(401).json({ error: 'Kimlik doğrulaması gerekli' });
        }
        if (!subject || !message) {
            return res.status(400).json({ error: 'Konu ve mesaj alanları gereklidir' });
        }
        const feedback = await database_1.prisma.feedback.create({
            data: {
                id: (0, ulid_1.ulid)(),
                user_id: userId,
                type: type || 'GENERAL',
                subject,
                message,
                priority: priority || 'MEDIUM'
            },
            include: {
                user: {
                    select: {
                        first_name: true,
                        last_name: true,
                        email: true
                    }
                }
            }
        });
        const admins = await database_1.prisma.users.findMany({
            where: { role: 'ADMIN' },
            select: { id: true }
        });
        for (const admin of admins) {
            await database_1.prisma.notifications.create({
                data: {
                    id: (0, ulid_1.ulid)(),
                    user_id: admin.id,
                    type: 'GENERAL',
                    title: 'Yeni Geri Bildirim',
                    message: `${feedback.user.first_name} ${feedback.user.last_name} tarafından "${feedback.subject}" konulu yeni geri bildirim gönderildi.`,
                    data: {
                        feedback_id: feedback.id,
                        feedback_type: feedback.type,
                        feedback_priority: feedback.priority,
                        user_name: `${feedback.user.first_name} ${feedback.user.last_name}`
                    }
                }
            });
        }
        (0, socket_1.emitToAdmins)('notification', {
            id: (0, ulid_1.ulid)(),
            type: 'GENERAL',
            title: 'Yeni Geri Bildirim',
            message: `${feedback.user.first_name} ${feedback.user.last_name} tarafından "${feedback.subject}" konulu yeni geri bildirim gönderildi.`,
            data: {
                feedback_id: feedback.id,
                feedback_type: feedback.type,
                feedback_priority: feedback.priority,
                user_name: `${feedback.user.first_name} ${feedback.user.last_name}`
            },
            created_at: new Date()
        });
        return res.status(201).json({
            success: true,
            message: 'Geri bildiriminiz başarıyla gönderildi',
            data: feedback
        });
    }
    catch (error) {
        console.error('Feedback oluşturma hatası:', error);
        return res.status(500).json({ error: 'İç sunucu hatası' });
    }
};
exports.createFeedback = createFeedback;
const getUserFeedbacks = async (req, res) => {
    try {
        const userId = req.user?.id;
        if (!userId) {
            return res.status(401).json({ error: 'Kimlik doğrulaması gerekli' });
        }
        const feedbacks = await database_1.prisma.feedback.findMany({
            where: { user_id: userId },
            orderBy: { created_at: 'desc' },
            include: {
                admin: {
                    select: {
                        first_name: true,
                        last_name: true
                    }
                }
            }
        });
        return res.json({
            success: true,
            data: feedbacks
        });
    }
    catch (error) {
        console.error('Feedback listeleme hatası:', error);
        return res.status(500).json({ error: 'İç sunucu hatası' });
    }
};
exports.getUserFeedbacks = getUserFeedbacks;
const getAllFeedbacks = async (req, res) => {
    try {
        console.log('getAllFeedbacks called with query:', req.query);
        const { page = 1, limit = 10, status, type, priority } = req.query;
        const offset = (Number(page) - 1) * Number(limit);
        const where = {};
        if (status)
            where.status = status;
        if (type)
            where.type = type;
        if (priority)
            where.priority = priority;
        console.log('Filter conditions:', where);
        const [feedbacks, total] = await Promise.all([
            database_1.prisma.feedback.findMany({
                where,
                skip: offset,
                take: Number(limit),
                orderBy: [
                    { priority: 'desc' },
                    { created_at: 'desc' }
                ],
                include: {
                    user: {
                        select: {
                            first_name: true,
                            last_name: true,
                            email: true
                        }
                    },
                    admin: {
                        select: {
                            first_name: true,
                            last_name: true
                        }
                    }
                }
            }),
            database_1.prisma.feedback.count({ where })
        ]);
        console.log('Found feedbacks:', feedbacks.length, 'Total:', total);
        res.json({
            success: true,
            data: {
                feedbacks,
                pagination: {
                    current_page: Number(page),
                    total_pages: Math.ceil(total / Number(limit)),
                    total_items: total,
                    items_per_page: Number(limit)
                }
            }
        });
    }
    catch (error) {
        console.error('Feedback admin listeleme hatası:', error);
        res.status(500).json({ error: 'İç sunucu hatası' });
    }
};
exports.getAllFeedbacks = getAllFeedbacks;
const respondToFeedback = async (req, res) => {
    try {
        const { id } = req.params;
        const { response, status } = req.body;
        const adminId = req.user?.id;
        if (!adminId) {
            res.status(401).json({ error: 'Admin yetkisi gerekli' });
            return;
        }
        if (!response) {
            res.status(400).json({ error: 'Yanıt metni gereklidir' });
            return;
        }
        const feedback = await database_1.prisma.feedback.update({
            where: { id },
            data: {
                admin_response: response,
                admin_id: adminId,
                status: status || 'RESOLVED',
                responded_at: new Date()
            },
            include: {
                user: {
                    select: {
                        id: true,
                        first_name: true,
                        last_name: true,
                        email: true
                    }
                }
            }
        });
        await database_1.prisma.notifications.create({
            data: {
                id: (0, ulid_1.ulid)(),
                user_id: feedback.user_id,
                type: 'FEEDBACK_RESPONSE',
                title: 'Geri Bildiriminize Yanıt',
                message: `"${feedback.subject}" konulu geri bildiriminize yanıt verildi.`,
                data: {
                    feedback_id: feedback.id,
                    feedback_subject: feedback.subject,
                    admin_response: response
                }
            }
        });
        (0, socket_1.emitToUser)(feedback.user_id, 'notification', {
            id: (0, ulid_1.ulid)(),
            type: 'FEEDBACK_RESPONSE',
            title: 'Geri Bildiriminize Yanıt',
            message: `"${feedback.subject}" konulu geri bildiriminize yanıt verildi.`,
            data: {
                feedback_id: feedback.id,
                feedback_subject: feedback.subject,
                admin_response: response
            },
            created_at: new Date()
        });
        res.json({
            success: true,
            message: 'Yanıt başarıyla gönderildi',
            data: feedback
        });
    }
    catch (error) {
        console.error('Feedback yanıtlama hatası:', error);
        res.status(500).json({ error: 'İç sunucu hatası' });
    }
};
exports.respondToFeedback = respondToFeedback;
const getFeedbackDetail = async (req, res) => {
    try {
        const { id } = req.params;
        const feedback = await database_1.prisma.feedback.findUnique({
            where: { id },
            include: {
                user: {
                    select: {
                        first_name: true,
                        last_name: true,
                        email: true,
                        phone: true
                    }
                },
                admin: {
                    select: {
                        first_name: true,
                        last_name: true
                    }
                }
            }
        });
        if (!feedback) {
            res.status(404).json({ error: 'Geri bildirim bulunamadı' });
            return;
        }
        res.json({
            success: true,
            data: feedback
        });
    }
    catch (error) {
        console.error('Feedback detay hatası:', error);
        res.status(500).json({ error: 'İç sunucu hatası' });
    }
};
exports.getFeedbackDetail = getFeedbackDetail;
const updateFeedbackStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        const feedback = await database_1.prisma.feedback.update({
            where: { id },
            data: { status }
        });
        res.json({
            success: true,
            message: 'Durum başarıyla güncellendi',
            data: feedback
        });
    }
    catch (error) {
        console.error('Feedback durum güncelleme hatası:', error);
        res.status(500).json({ error: 'İç sunucu hatası' });
    }
};
exports.updateFeedbackStatus = updateFeedbackStatus;
const getFeedbackStats = async (req, res) => {
    try {
        const [totalFeedbacks, openFeedbacks, resolvedFeedbacks, urgentFeedbacks, todayFeedbacks] = await Promise.all([
            database_1.prisma.feedback.count(),
            database_1.prisma.feedback.count({ where: { status: 'OPEN' } }),
            database_1.prisma.feedback.count({ where: { status: 'RESOLVED' } }),
            database_1.prisma.feedback.count({ where: { priority: 'URGENT' } }),
            database_1.prisma.feedback.count({
                where: {
                    created_at: {
                        gte: new Date(new Date().setHours(0, 0, 0, 0))
                    }
                }
            })
        ]);
        const typeStats = await database_1.prisma.feedback.groupBy({
            by: ['type'],
            _count: { _all: true }
        });
        const priorityStats = await database_1.prisma.feedback.groupBy({
            by: ['priority'],
            _count: { _all: true }
        });
        res.json({
            success: true,
            data: {
                total: totalFeedbacks,
                open: openFeedbacks,
                resolved: resolvedFeedbacks,
                urgent: urgentFeedbacks,
                today: todayFeedbacks,
                byType: typeStats,
                byPriority: priorityStats
            }
        });
    }
    catch (error) {
        console.error('Feedback istatistik hatası:', error);
        res.status(500).json({ error: 'İç sunucu hatası' });
    }
};
exports.getFeedbackStats = getFeedbackStats;
