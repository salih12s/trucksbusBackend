"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createReport = createReport;
exports.listMyReports = listMyReports;
exports.adminListReports = adminListReports;
exports.adminGetReport = adminGetReport;
exports.adminUpdateStatus = adminUpdateStatus;
const database_1 = require("../utils/database");
const socket_1 = require("../utils/socket");
const notificationService_1 = require("./notificationService");
async function createReport({ listingId, reporterId, description, reason, }) {
    const listing = await database_1.prisma.listings.findUnique({
        where: { id: listingId },
        select: { id: true, user_id: true, title: true }
    });
    if (!listing)
        throw new Error("Listing not found");
    if (listing.user_id === reporterId)
        throw new Error("You cannot report your own listing");
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recent = await database_1.prisma.reports.findFirst({
        where: { listing_id: listingId, reporter_id: reporterId, created_at: { gte: since } },
    });
    if (recent) {
        const e = new Error("You already reported this listing in the last 24h");
        e.code = 429;
        throw e;
    }
    const created = await database_1.prisma.$transaction(async (tx) => {
        const report = await tx.reports.create({
            data: {
                listing_id: listingId,
                reporter_id: reporterId,
                owner_id: listing.user_id,
                reason,
                description,
                status: 'OPEN',
            },
            include: {
                reporter: { select: { id: true, first_name: true, last_name: true } },
                listing: { select: { title: true } },
            },
        });
        await tx.report_history.create({
            data: {
                report_id: report.id,
                action: 'CREATE',
                note: 'Report created',
            },
        });
        return report;
    });
    (0, socket_1.emitToAdmins)('admin:report:new', {
        reportId: created.id,
        listingId,
        listingTitle: created.listing?.title || 'İlan',
        reporterName: `${created.reporter.first_name} ${created.reporter.last_name}`,
        reason,
        createdAt: created.created_at,
    });
    try {
        const admins = await database_1.prisma.users.findMany({
            where: { role: 'ADMIN', is_active: true },
            select: { id: true }
        });
        if (admins.length) {
            await database_1.prisma.notifications.createMany({
                data: admins.map(a => ({
                    id: `admin_report_${created.id}_${a.id}_${Date.now()}`,
                    user_id: a.id,
                    type: 'REPORT_NEW',
                    title: 'Yeni şikayet',
                    message: `"${created.listing?.title ?? 'İlan'}" için şikayet oluşturuldu`,
                    data: { reportId: created.id, listingId },
                }))
            });
        }
    }
    catch (error) {
        console.error('Error creating admin notifications:', error);
    }
    return created;
}
async function listMyReports(userId, q) {
    const page = q.page && q.page > 0 ? q.page : 1;
    const limit = q.limit && q.limit > 0 ? q.limit : 10;
    const where = { reporter_id: userId };
    if (q.status)
        where.status = q.status;
    const [items, total] = await Promise.all([
        database_1.prisma.reports.findMany({
            where,
            include: {
                listing: { select: { id: true, title: true } },
                history: {
                    include: { actor: { select: { id: true, first_name: true, last_name: true } } },
                    orderBy: { created_at: 'asc' }
                },
            },
            orderBy: { created_at: 'desc' },
            skip: (page - 1) * limit,
            take: limit,
        }),
        database_1.prisma.reports.count({ where }),
    ]);
    return { items, total, page, limit };
}
async function adminListReports(params) {
    const page = params.page && params.page > 0 ? params.page : 1;
    const limit = params.limit && params.limit > 0 ? params.limit : 20;
    const where = {};
    if (params.status)
        where.status = params.status;
    if (params.reason)
        where.reason = params.reason;
    if (params.listingId)
        where.listing_id = params.listingId;
    if (params.q && params.q.trim()) {
        const searchTerm = params.q.trim();
        where.OR = [
            { description: { contains: searchTerm, mode: 'insensitive' } },
            { listing: { title: { contains: searchTerm, mode: 'insensitive' } } },
            {
                reporter: {
                    OR: [
                        { first_name: { contains: searchTerm, mode: 'insensitive' } },
                        { last_name: { contains: searchTerm, mode: 'insensitive' } },
                    ]
                }
            },
        ];
    }
    const [items, total] = await Promise.all([
        database_1.prisma.reports.findMany({
            where,
            include: {
                listing: { select: { id: true, title: true } },
                reporter: { select: { id: true, first_name: true, last_name: true } },
                reviewer: { select: { id: true, first_name: true, last_name: true } },
            },
            orderBy: { created_at: 'desc' },
            skip: (page - 1) * limit,
            take: limit,
        }),
        database_1.prisma.reports.count({ where }),
    ]);
    return { items, total, page, limit };
}
async function adminGetReport(id) {
    const report = await database_1.prisma.reports.findUnique({
        where: { id },
        include: {
            listing: { select: { id: true, title: true, price: true } },
            reporter: { select: { id: true, first_name: true, last_name: true } },
            owner: { select: { id: true, first_name: true, last_name: true } },
            reviewer: { select: { id: true, first_name: true, last_name: true } },
            history: {
                include: { actor: { select: { id: true, first_name: true, last_name: true } } },
                orderBy: { created_at: 'asc' }
            },
        },
    });
    if (!report)
        throw new Error('Report not found');
    return report;
}
async function adminUpdateStatus({ id, reviewerId, status, resolutionNote, removeListing, }) {
    const report = await database_1.prisma.reports.findUnique({
        where: { id },
        select: { id: true, status: true, updated_at: true, reporter_id: true, listing_id: true }
    });
    if (!report)
        throw new Error('Report not found');
    if (['ACCEPTED', 'REJECTED'].includes(report.status)) {
        throw new Error('Resolved reports cannot be changed');
    }
    if (status === 'UNDER_REVIEW' && report.status !== 'OPEN') {
        throw new Error('Only OPEN → UNDER_REVIEW allowed');
    }
    if (status === 'REJECTED' && !resolutionNote) {
        throw new Error('Resolution note is required when rejecting');
    }
    if (removeListing && status !== 'ACCEPTED') {
        throw new Error('removeListing only allowed when ACCEPTED');
    }
    const updated = await database_1.prisma.$transaction(async (tx) => {
        const prev = report.status;
        const updatedCount = await tx.reports.updateMany({
            where: { id, updated_at: report.updated_at },
            data: {
                status: status,
                resolution_note: resolutionNote ?? null,
                reviewer_id: reviewerId,
            },
        });
        if (updatedCount.count === 0) {
            throw new Error('Conflict: report was modified. Refresh and retry.');
        }
        const r = await tx.reports.findUnique({
            where: { id },
            include: {
                reporter: { select: { id: true, first_name: true, last_name: true } },
                owner: { select: { id: true } },
                listing: { select: { id: true, title: true } },
                reviewer: { select: { id: true, first_name: true, last_name: true } },
            },
        });
        if (!r) {
            throw new Error('Report not found after update');
        }
        await tx.report_history.create({
            data: {
                report_id: r.id,
                actor_id: reviewerId,
                action: 'STATUS_CHANGE',
                from_status: prev,
                to_status: status,
                note: resolutionNote ?? undefined,
            },
        });
        if (status === 'ACCEPTED' && removeListing) {
            await tx.listings.update({
                where: { id: r.listing_id },
                data: { moderation_status: 'REMOVED_BY_MODERATION', is_active: false },
            });
            await tx.report_history.create({
                data: {
                    report_id: r.id,
                    actor_id: reviewerId,
                    action: 'LISTING_REMOVED',
                    note: 'Listing removed by moderation',
                },
            });
        }
        return r;
    });
    try {
        if (status === 'REJECTED') {
            await notificationService_1.NotificationService.createReportNotification(updated.reporter_id, 'REPORT_RESOLVED_REJECTED', 'Şikayetiniz Reddedildi', `"${updated.listing?.title || 'İlan'}" için şikayetiniz reddedildi.\n\nRed Gerekçesi: ${resolutionNote}`, {
                reportId: updated.id,
                reportTitle: updated.listing?.title || 'İlan',
                oldStatus: report.status,
                newStatus: status,
                resolutionNote,
            });
        }
        else {
            await notificationService_1.NotificationService.createReportNotification(updated.reporter_id, status === 'ACCEPTED' ? 'REPORT_RESOLVED_ACCEPTED' : 'GENERAL', 'Şikayet Durumu Güncellendi', `"${updated.listing?.title || 'İlan'}" için şikayetinizin durumu ${status === 'ACCEPTED' ? 'kabul edildi' : 'güncellendi'}.`, {
                reportId: updated.id,
                reportTitle: updated.listing?.title || 'İlan',
                oldStatus: report.status,
                newStatus: status,
            });
        }
        if (status === 'ACCEPTED' && removeListing && updated.owner_id !== updated.reporter_id) {
            await notificationService_1.NotificationService.createReportNotification(updated.owner_id, 'LISTING_REMOVED', 'İlanınız Moderasyon Sonucu Kaldırıldı', `"${updated.listing?.title || 'İlan'}" adlı ilanınız şikayet sonucu kaldırılmıştır.`, {
                reportId: updated.id,
                reportTitle: updated.listing?.title || 'İlan',
            });
        }
        (0, socket_1.emitToUser)(updated.reporter_id, 'user:report:status-update', {
            reportId: updated.id,
            reporterId: updated.reporter_id,
            listingId: updated.listing_id,
            oldStatus: report.status,
            newStatus: status,
            resolutionNote,
            updatedAt: new Date().toISOString()
        });
        (0, socket_1.emitToAdmins)('admin:report:resolved', {
            reportId: updated.id,
            listingTitle: updated.listing?.title || 'İlan',
            status,
            reviewerName: `${updated.reviewer?.first_name ?? ''} ${updated.reviewer?.last_name ?? ''}`.trim(),
            resolvedAt: new Date(),
        });
    }
    catch (error) {
        console.error('Error sending notifications:', error);
    }
    return updated;
}
