"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const locationController_1 = require("../controllers/locationController");
const router = (0, express_1.Router)();
router.get('/cities', locationController_1.getCities);
router.get('/cities/:cityId/districts', locationController_1.getDistrictsByCity);
exports.default = router;
