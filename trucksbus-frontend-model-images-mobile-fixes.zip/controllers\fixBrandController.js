"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fixBrandImages = void 0;
const database_1 = require("../utils/database");
const logger_1 = require("../utils/logger");
const imageFixMap = {
    '/ModelImage/Scanıa.png': '/ModelImage/Scania.png',
    '/ModelImage/Avıa.png': '/ModelImage/Avia.png',
    '/ModelImage/MUSATTİ.png': '/ModelImage/Musatti.png',
    '/ModelImage/Türkkar.png': '/ModelImage/Turkkar.png',
    '/ModelImage/Centro.png': '/ModelImage/Cenntro.png',
    '/ModelImage/Axiam.png': '/ModelImage/Aixam.png',
};
const fixBrandImages = async (req, res) => {
    try {
        logger_1.logger.info('🔧 Brand image URLs düzeltiliyor...');
        const results = [];
        for (const [oldUrl, newUrl] of Object.entries(imageFixMap)) {
            logger_1.logger.info(`🔄 Değiştiriliyor: ${oldUrl} → ${newUrl}`);
            const result = await database_1.prisma.brands.updateMany({
                where: {
                    image_url: oldUrl
                },
                data: {
                    image_url: newUrl
                }
            });
            results.push({
                oldUrl,
                newUrl,
                updatedCount: result.count
            });
            logger_1.logger.info(`✅ ${result.count} brand güncellendi`);
        }
        const updatedBrands = await database_1.prisma.brands.findMany({
            where: {
                image_url: {
                    in: Object.values(imageFixMap)
                }
            },
            select: {
                name: true,
                image_url: true
            }
        });
        logger_1.logger.info('🎉 Brand image URL düzeltmeleri tamamlandı!');
        res.json({
            success: true,
            message: 'Brand image URLs başarıyla düzeltildi',
            results,
            updatedBrands
        });
    }
    catch (error) {
        logger_1.logger.error('❌ Brand image fix error:', error);
        res.status(500).json({
            success: false,
            error: 'Brand image URLs düzeltilirken hata oluştu'
        });
    }
};
exports.fixBrandImages = fixBrandImages;
