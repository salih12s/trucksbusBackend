"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsController = void 0;
const reportService2_1 = require("../services/reportService2");
const client_1 = require("@prisma/client");
function validateReportInput(listingId, reasonCode, description) {
    const errors = [];
    if (!listingId?.trim())
        errors.push('listingId is required');
    if (!reasonCode?.trim())
        errors.push('reasonCode is required');
    if (!description?.trim())
        errors.push('description is required');
    if (description && description.trim().length < 10) {
        errors.push('Description must be at least 10 characters');
    }
    if (description && description.trim().length > 2000) {
        errors.push('Description must be less than 2000 characters');
    }
    const validReasons = Object.values(client_1.ReportReason);
    if (reasonCode && !validReasons.includes(reasonCode)) {
        errors.push('Invalid reason code');
    }
    if (reasonCode === 'OTHER' && description && description.trim().length < 20) {
        errors.push('Other reason requires at least 20 characters');
    }
    return errors;
}
function validateStatusUpdate(status, resolutionNote) {
    const errors = [];
    const validStatuses = ['OPEN', 'UNDER_REVIEW', 'ACCEPTED', 'REJECTED'];
    if (!status)
        errors.push('status is required');
    if (!validStatuses.includes(status))
        errors.push('Invalid status');
    if (resolutionNote && resolutionNote.length > 1000) {
        errors.push('Resolution note must be less than 1000 characters');
    }
    if (status === 'REJECTED' && (!resolutionNote || resolutionNote.trim().length < 10)) {
        errors.push('Resolution note is required and must be at least 10 characters when rejecting');
    }
    return errors;
}
class ReportsController {
    static async createReport(req, res) {
        try {
            const userId = req.user?.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            const { listingId, reasonCode, description } = req.body;
            const validationErrors = validateReportInput(listingId, reasonCode, description);
            if (validationErrors.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: validationErrors[0]
                });
            }
            const report = await (0, reportService2_1.createReport)({
                listingId,
                reporterId: userId,
                reason: reasonCode,
                description: description.trim(),
            });
            return res.status(201).json({
                success: true,
                data: { id: report.id, status: report.status },
                message: 'Report created successfully'
            });
        }
        catch (error) {
            console.error('Create report error:', error);
            const status = error?.code === 429 ? 429 : 400;
            return res.status(status).json({
                success: false,
                message: error.message || 'Failed to create report'
            });
        }
    }
    static async getMyReports(req, res) {
        try {
            const userId = req.user?.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            const status = req.query.status;
            const page = Number(req.query.page) || 1;
            const limit = Number(req.query.limit) || 10;
            const result = await (0, reportService2_1.listMyReports)(userId, { status, page, limit });
            return res.json({
                success: true,
                ...result
            });
        }
        catch (error) {
            console.error('Get my reports error:', error);
            return res.status(500).json({
                success: false,
                message: 'Failed to fetch reports'
            });
        }
    }
    static async adminGetReports(req, res) {
        try {
            const userRole = req.user?.role;
            if (userRole !== 'ADMIN') {
                return res.status(403).json({ success: false, message: 'Admin access required' });
            }
            const status = req.query.status;
            const reason = req.query.reason;
            const listingId = req.query.listingId;
            const q = req.query.q;
            const page = Number(req.query.page) || 1;
            const limit = Number(req.query.limit) || 20;
            const result = await (0, reportService2_1.adminListReports)({ status, reason, listingId, q, page, limit });
            return res.json({
                success: true,
                ...result
            });
        }
        catch (error) {
            console.error('Admin get reports error:', error);
            return res.status(500).json({
                success: false,
                message: 'Failed to fetch reports'
            });
        }
    }
    static async adminGetReportDetail(req, res) {
        try {
            const userRole = req.user?.role;
            if (userRole !== 'ADMIN') {
                return res.status(403).json({ success: false, message: 'Admin access required' });
            }
            const reportId = req.params.id;
            const report = await (0, reportService2_1.adminGetReport)(reportId);
            return res.json({
                success: true,
                data: report
            });
        }
        catch (error) {
            console.error('Admin get report detail error:', error);
            return res.status(404).json({
                success: false,
                message: error.message || 'Report not found'
            });
        }
    }
    static async adminUpdateReportStatus(req, res) {
        try {
            const userRole = req.user?.role;
            const userId = req.user?.id;
            if (userRole !== 'ADMIN' || !userId) {
                return res.status(403).json({ success: false, message: 'Admin access required' });
            }
            const reportId = req.params.id;
            const { status, resolutionNote, removeListing } = req.body;
            const validationErrors = validateStatusUpdate(status, resolutionNote);
            if (validationErrors.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: validationErrors[0]
                });
            }
            const updated = await (0, reportService2_1.adminUpdateStatus)({
                id: reportId,
                reviewerId: userId,
                status: status,
                resolutionNote,
                removeListing: Boolean(removeListing),
            });
            return res.json({
                success: true,
                data: updated,
                message: 'Report status updated successfully'
            });
        }
        catch (error) {
            console.error('Admin update report status error:', error);
            return res.status(400).json({
                success: false,
                message: error.message || 'Failed to update report status'
            });
        }
    }
}
exports.ReportsController = ReportsController;
