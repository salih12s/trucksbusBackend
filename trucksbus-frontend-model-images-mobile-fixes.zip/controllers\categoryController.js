"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getVariants = exports.getModels = exports.getBrands = exports.getVehicleTypes = exports.getCategories = void 0;
const database_1 = require("../utils/database");
const logger_1 = require("../utils/logger");
const getCategories = async (req, res) => {
    try {
        const categories = await database_1.prisma.categories.findMany({
            orderBy: { name: 'asc' }
        });
        res.json(categories);
    }
    catch (error) {
        logger_1.logger.error('Error fetching categories:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getCategories = getCategories;
const getVehicleTypes = async (req, res) => {
    try {
        const { categoryId } = req.params;
        const category_id = categoryId || req.query.category_id;
        console.log(`🔍 VehicleTypes request - categoryId: ${categoryId}, category_id: ${category_id}`);
        let vehicleTypes;
        if (category_id) {
            vehicleTypes = await database_1.prisma.vehicle_types.findMany({
                where: { category_id },
                include: {
                    categories: true
                },
                orderBy: { name: 'asc' }
            });
            console.log(`🔍 Vehicle types query with filter: category_id=${category_id}, found ${vehicleTypes.length} vehicle types`);
        }
        else {
            vehicleTypes = await database_1.prisma.vehicle_types.findMany({
                include: {
                    categories: true
                },
                orderBy: { name: 'asc' }
            });
            console.log(`🔍 Vehicle types query without filter, found ${vehicleTypes.length} vehicle types`);
        }
        res.json(vehicleTypes);
    }
    catch (error) {
        logger_1.logger.error('Error fetching vehicle types:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getVehicleTypes = getVehicleTypes;
const getBrands = async (req, res) => {
    try {
        const { vehicleTypeId } = req.params;
        const vehicle_type_id = vehicleTypeId || req.query.vehicle_type_id;
        console.log(`🔍 Brands request - vehicleTypeId: ${vehicleTypeId}, vehicle_type_id: ${vehicle_type_id}`);
        let brands;
        if (vehicle_type_id) {
            brands = await database_1.prisma.brands.findMany({
                where: { vehicle_type_id },
                include: {
                    vehicle_types: true
                },
                orderBy: { name: 'asc' }
            });
            console.log(`🔍 Brands query with filter: vehicle_type_id=${vehicle_type_id}, found ${brands.length} brands`);
        }
        else {
            brands = await database_1.prisma.brands.findMany({
                include: {
                    vehicle_types: true
                },
                orderBy: { name: 'asc' }
            });
            console.log(`🔍 Brands query without filter, found ${brands.length} brands`);
        }
        res.json(brands);
    }
    catch (error) {
        logger_1.logger.error('Error fetching brands:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getBrands = getBrands;
const getModels = async (req, res) => {
    try {
        const { brandId } = req.params;
        const brand_id = brandId || req.query.brand_id;
        console.log(`🔍 Models request - brandId: ${brandId}, brand_id: ${brand_id}`);
        let models;
        if (brand_id) {
            models = await database_1.prisma.models.findMany({
                where: { brand_id },
                include: {
                    brands: true
                },
                orderBy: { name: 'asc' }
            });
            console.log(`🔍 Models query with filter: brand_id=${brand_id}, found ${models.length} models`);
        }
        else {
            models = await database_1.prisma.models.findMany({
                include: {
                    brands: true
                },
                orderBy: { name: 'asc' }
            });
            console.log(`🔍 Models query without filter, found ${models.length} models`);
        }
        res.json(models);
    }
    catch (error) {
        logger_1.logger.error('Error fetching models:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getModels = getModels;
const getVariants = async (req, res) => {
    try {
        const { modelId } = req.params;
        const model_id = modelId || req.query.model_id;
        console.log(`🔍 Variants request - modelId: ${modelId}, model_id: ${model_id}`);
        let variants;
        if (model_id) {
            variants = await database_1.prisma.variants.findMany({
                where: { model_id },
                include: {
                    models: true
                },
                orderBy: { name: 'asc' }
            });
            console.log(`🔍 Variants query with filter: model_id=${model_id}, found ${variants.length} variants`);
        }
        else {
            variants = await database_1.prisma.variants.findMany({
                include: {
                    models: true
                },
                orderBy: { name: 'asc' }
            });
            console.log(`🔍 Variants query without filter, found ${variants.length} variants`);
        }
        res.json(variants);
    }
    catch (error) {
        logger_1.logger.error('Error fetching variants:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getVariants = getVariants;
