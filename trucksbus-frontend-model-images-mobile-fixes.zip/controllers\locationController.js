"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDistrictsByCity = exports.getCities = void 0;
const database_1 = require("../utils/database");
const logger_1 = require("../utils/logger");
const getCities = async (req, res) => {
    try {
        const cities = await database_1.prisma.cities.findMany({
            orderBy: { name: 'asc' }
        });
        res.json(cities);
    }
    catch (error) {
        logger_1.logger.error('Error fetching cities:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getCities = getCities;
const getDistrictsByCity = async (req, res) => {
    try {
        const { cityId } = req.params;
        const districts = await database_1.prisma.districts.findMany({
            where: {
                city_id: cityId
            },
            orderBy: { name: 'asc' }
        });
        res.json(districts);
    }
    catch (error) {
        logger_1.logger.error('Error fetching districts:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
exports.getDistrictsByCity = getDistrictsByCity;
