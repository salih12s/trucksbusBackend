"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const compression_1 = __importDefault(require("compression"));
const morgan_1 = __importDefault(require("morgan"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
const http_1 = require("http");
const socket_io_1 = require("socket.io");
const socket_1 = require("./utils/socket");
const authRoutes_1 = __importDefault(require("./routes/authRoutes"));
const listingRoutes_1 = __importDefault(require("./routes/listingRoutes"));
const adminRoutes_1 = __importDefault(require("./routes/adminRoutes"));
const categoryRoutes_1 = __importDefault(require("./routes/categoryRoutes"));
const locationRoutes_1 = __importDefault(require("./routes/locationRoutes"));
const conversationsRoutes_1 = __importDefault(require("./routes/conversationsRoutes"));
const reportRoutes_1 = __importDefault(require("./routes/reportRoutes"));
const notificationRoutes_1 = __importDefault(require("./routes/notificationRoutes"));
const favorites_1 = __importDefault(require("./routes/favorites"));
const meRoutes_1 = __importDefault(require("./routes/meRoutes"));
const feedbackRoutes_1 = __importDefault(require("./routes/feedbackRoutes"));
const logger_1 = require("./utils/logger");
const database_1 = require("./utils/database");
dotenv_1.default.config();
const app = (0, express_1.default)();
exports.app = app;
const server = (0, http_1.createServer)(app);
const io = new socket_io_1.Server(server, {
    cors: {
        origin: process.env.NODE_ENV === 'production'
            ? [
                "https://trucksbus.com",
                "https://www.trucksbus.com",
                "https://trucksbus.com.tr",
                "https://www.trucksbus.com.tr"
            ]
            : ["http://localhost:5173", "http://localhost:5174"],
        methods: ["GET", "POST"],
        credentials: true
    }
});
const limiter = (0, express_rate_limit_1.default)({
    windowMs: 1 * 60 * 1000,
    max: process.env.NODE_ENV === 'production' ? 1000 : 200,
    message: {
        success: false,
        message: 'Too many requests from this IP, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
});
app.use((0, helmet_1.default)());
app.use((0, cors_1.default)({
    origin: process.env.NODE_ENV === 'production'
        ? [
            "https://trucksbus.com",
            "https://www.trucksbus.com",
            "https://trucksbus.com.tr",
            "https://www.trucksbus.com.tr"
        ]
        : ["http://localhost:5173", "http://localhost:5174"],
    credentials: true
}));
app.use((0, compression_1.default)());
app.use((0, morgan_1.default)('combined'));
app.use(limiter);
app.use(express_1.default.json({ limit: '10mb' }));
app.use(express_1.default.urlencoded({ extended: true, limit: '10mb' }));
const uploadsPath = process.env.NODE_ENV === 'production'
    ? path_1.default.join(__dirname, '..', 'public', 'uploads')
    : path_1.default.resolve('C:/Users/salih/Desktop/TruckBus/Backend/public/uploads');
console.log('🖼️ Static uploads path:', uploadsPath);
app.use('/uploads', express_1.default.static(uploadsPath));
app.use((req, res, next) => {
    req.io = io;
    next();
});
app.get('/api/health', (req, res) => {
    console.log('Health check called at:', new Date().toISOString());
    res.status(200).send('OK');
});
app.get('/', (req, res) => {
    res.status(200).send('TruckBus Backend is running!');
});
app.use('/api/auth', authRoutes_1.default);
app.use('/api/categories', categoryRoutes_1.default);
app.use('/api/locations', locationRoutes_1.default);
app.use('/api/listings', listingRoutes_1.default);
app.use('/api/admin', adminRoutes_1.default);
app.use('/api/conversations', conversationsRoutes_1.default);
app.use('/api/me', meRoutes_1.default);
app.use('/api/favorites', favorites_1.default);
app.use('/api/reports', reportRoutes_1.default);
app.use('/api/notifications', notificationRoutes_1.default);
app.use('/api', feedbackRoutes_1.default);
app.use((err, req, res, next) => {
    logger_1.logger.error('Error:', err);
    res.status(err.status || 500).json({
        success: false,
        message: err.message || 'Internal server error'
    });
});
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Route not found'
    });
});
app.use((err, req, res, next) => {
    const status = err.status || 500;
    const message = err.message || 'Internal Server Error';
    logger_1.logger.error('❌ Global Error Handler:', {
        status,
        message,
        url: req.url,
        method: req.method,
        stack: err.stack
    });
    res.status(status).json({
        success: false,
        message,
        ...(err.details ? { details: err.details } : {})
    });
});
async function connectDatabase() {
    try {
        await database_1.prisma.$connect();
        logger_1.logger.info('✅ Database connected successfully');
    }
    catch (error) {
        logger_1.logger.error('❌ Database connection failed:', error);
        throw error;
    }
}
process.on('SIGTERM', async () => {
    logger_1.logger.info('SIGTERM signal received');
    await database_1.prisma.$disconnect();
    process.exit(0);
});
process.on('SIGINT', async () => {
    logger_1.logger.info('SIGINT signal received');
    await database_1.prisma.$disconnect();
    process.exit(0);
});
async function startServer() {
    console.log('🔧 Starting server...');
    console.log('🔧 NODE_ENV:', process.env.NODE_ENV);
    console.log('🔧 PORT:', process.env.PORT);
    console.log('🔧 DATABASE_URL exists:', !!process.env.DATABASE_URL);
    try {
        try {
            await connectDatabase();
            console.log('✅ Database connected successfully');
            logger_1.logger.info('✅ Database connected successfully');
        }
        catch (dbError) {
            console.error('❌ Database connection failed, but server will continue:', dbError);
            logger_1.logger.error('❌ Database connection failed, but server will continue:', dbError);
        }
        (0, socket_1.initSocket)(io);
        console.log('✅ Socket.IO initialized');
        const actualPort = Number(process.env.PORT) || 3001;
        console.log('🔧 Attempting to listen on port:', actualPort);
        server.listen(actualPort, '0.0.0.0', () => {
            console.log(`🚀 Server running on 0.0.0.0:${actualPort}`);
            console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
            console.log(`🌐 Frontend URL: ${process.env.FRONTEND_URL || 'http://localhost:5173'}`);
            console.log(`💬 Socket.IO enabled with room management`);
            console.log(`🩺 Health check available at /api/health`);
            logger_1.logger.info(`🚀 Server running on 0.0.0.0:${actualPort}`);
            logger_1.logger.info(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
            logger_1.logger.info(`🌐 Frontend URL: ${process.env.FRONTEND_URL || 'http://localhost:5173'}`);
            logger_1.logger.info(`💬 Socket.IO enabled with room management`);
        });
    }
    catch (error) {
        console.error('💥 Failed to start server:', error);
        logger_1.logger.error('Failed to start server:', error);
        process.exit(1);
    }
}
startServer();
