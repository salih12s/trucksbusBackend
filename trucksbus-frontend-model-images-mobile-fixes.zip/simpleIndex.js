"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const http_1 = require("http");
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const compression_1 = __importDefault(require("compression"));
const morgan_1 = __importDefault(require("morgan"));
const dotenv_1 = __importDefault(require("dotenv"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const ulid_1 = require("ulid");
const logger_1 = require("./utils/logger");
const database_1 = require("./utils/database");
const socketService_1 = require("./services/socketService");
const favorites_1 = __importDefault(require("./routes/favorites"));
const meRoutes_1 = __importDefault(require("./routes/meRoutes"));
dotenv_1.default.config();
const app = (0, express_1.default)();
const server = (0, http_1.createServer)(app);
const PORT = process.env.PORT || 3005;
const socketService = new socketService_1.SocketService(server);
app.set('socketService', socketService);
app.use((0, helmet_1.default)());
app.use((0, cors_1.default)({
    origin: ['http://localhost:3000', 'http://localhost:5173'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use((0, compression_1.default)());
app.use((0, morgan_1.default)('combined'));
app.use(express_1.default.json({ limit: '10mb' }));
app.use(express_1.default.urlencoded({ extended: true }));
app.get('/health', async (req, res) => {
    try {
        await database_1.prisma.$queryRaw `SELECT 1`;
        res.json({
            success: true,
            message: 'TruckBus Backend API is running',
            database: 'connected',
            timestamp: new Date().toISOString()
        });
    }
    catch (error) {
        logger_1.logger.error('Health check failed:', error);
        res.status(500).json({
            success: false,
            message: 'Health check failed',
            database: 'disconnected',
            timestamp: new Date().toISOString()
        });
    }
});
app.get('/test/pending-listings', async (req, res) => {
    try {
        const listings = await database_1.prisma.listings.findMany({
            where: { status: 'PENDING' },
            include: {
                categories: true,
                users: {
                    select: {
                        id: true,
                        first_name: true,
                        last_name: true,
                        email: true,
                        phone: true
                    }
                }
            },
            orderBy: { created_at: 'desc' }
        });
        res.json({
            success: true,
            count: listings.length,
            data: listings
        });
    }
    catch (error) {
        logger_1.logger.error('Test pending listings error:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching pending listings'
        });
    }
});
app.get('/api/auth/whoami', async (req, res) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader?.startsWith('Bearer ')) {
            res.status(401).json({ success: false, message: 'No token' });
            return;
        }
        const token = authHeader.substring(7);
        const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
        const user = await database_1.prisma.users.findUnique({
            where: { id: decoded.id },
            select: { id: true, email: true, role: true, first_name: true, last_name: true, is_active: true }
        });
        res.json({ success: true, user, decoded });
    }
    catch (error) {
        res.status(401).json({ success: false, error: error.message });
    }
});
app.get('/test/users', async (req, res) => {
    try {
        const users = await database_1.prisma.users.findMany({
            select: {
                id: true,
                username: true,
                email: true,
                role: true,
                created_at: true
            }
        });
        res.json({ success: true, count: users.length, data: users });
    }
    catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ success: false, message: 'Error fetching users' });
    }
});
app.get('/test/reports', async (req, res) => {
    try {
        const reports = await database_1.prisma.reports.findMany({
            include: {
                reporter: { select: { first_name: true, last_name: true } },
                listing: { select: { title: true } }
            }
        });
        res.json({ success: true, count: reports.length, data: reports });
    }
    catch (error) {
        console.error('Error fetching reports:', error);
        res.status(500).json({ success: false, message: 'Error fetching reports' });
    }
});
app.get('/test/categories', async (req, res) => {
    try {
        const categories = await database_1.prisma.categories.findMany({
            select: {
                id: true,
                name: true
            }
        });
        res.json({ success: true, count: categories.length, data: categories });
    }
    catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({ success: false, message: 'Error fetching categories' });
    }
});
app.post('/test/create-listing', async (req, res) => {
    try {
        const user = await database_1.prisma.users.findFirst();
        if (!user) {
            return res.status(400).json({
                success: false,
                message: 'No user found in database'
            });
        }
        const listing = await database_1.prisma.listings.create({
            data: {
                id: (0, ulid_1.ulid)(),
                title: "Test İlanı - 2020 Mercedes Actros",
                description: "Bu bir test ilanıdır.",
                price: 500000,
                year: 2020,
                km: 100000,
                category_id: "vehicle-category-001",
                vehicle_type_id: "cme633w8v0001981ksnpl6dj4",
                brand_id: "cme63joza00058jr35kfzpxii",
                model_id: "cme6433k50001a81vx38fdgpl",
                city_id: "cme60juon000q8vo1t9zrtn3v",
                district_id: "cme60juoq000r8vo1bultamcw",
                seller_name: "Test Kullanıcı",
                seller_phone: "5555555555",
                seller_email: "test@example.com",
                color: "Beyaz",
                fuel_type: "Dizel",
                transmission: "Manuel",
                vehicle_condition: "İyi",
                user_id: user.id,
                status: 'PENDING',
                is_pending: true,
                is_active: false,
                is_approved: false,
                updated_at: new Date()
            }
        });
        return res.json({
            success: true,
            message: 'Test listing created',
            data: listing
        });
    }
    catch (error) {
        logger_1.logger.error('Create test listing error:', error);
        return res.status(500).json({
            success: false,
            message: 'Error creating test listing',
            error: error.message
        });
    }
});
try {
    const categoryRoutes = require('./routes/categoryRoutes').default;
    app.use('/api/categories', categoryRoutes);
    logger_1.logger.info('Category routes loaded');
}
catch (error) {
    logger_1.logger.error('Failed to load category routes:', error);
}
try {
    const authRoutes = require('./routes/authRoutes').default;
    app.use('/api/auth', authRoutes);
    logger_1.logger.info('Auth routes loaded');
}
catch (error) {
    logger_1.logger.error('Failed to load auth routes:', error);
}
try {
    const locationRoutes = require('./routes/locationRoutes').default;
    app.use('/api/locations', locationRoutes);
    logger_1.logger.info('Location routes loaded');
}
catch (error) {
    logger_1.logger.error('Failed to load location routes:', error);
}
try {
    const conversationsRoutes = require('./routes/conversationsRoutes').default;
    app.use('/api/conversations', conversationsRoutes);
    logger_1.logger.info('Conversations routes loaded');
}
catch (error) {
    logger_1.logger.error('Failed to load conversations routes:', error);
}
try {
    const adminRoutes = require('./routes/adminRoutes').default;
    app.use('/api/admin', adminRoutes);
    logger_1.logger.info('Admin routes loaded');
}
catch (error) {
    logger_1.logger.error('Failed to load admin routes:', error);
}
try {
    const listingRoutes = require('./routes/listingRoutes').default;
    app.use('/api/listings', listingRoutes);
    logger_1.logger.info('Listing routes loaded');
}
catch (error) {
    logger_1.logger.error('Failed to load listing routes:', error);
}
try {
    if (!favorites_1.default) {
        logger_1.logger.error('favorites routes is undefined - check export');
    }
    else {
        app.use('/api/favorites', favorites_1.default);
        logger_1.logger.info('Favorites routes loaded');
    }
}
catch (error) {
    logger_1.logger.error('Failed to load favorites routes:', error);
}
try {
    if (!meRoutes_1.default) {
        logger_1.logger.error('me routes is undefined - check export');
    }
    else {
        app.use('/api/me', meRoutes_1.default);
        logger_1.logger.info('Me routes loaded');
    }
}
catch (error) {
    logger_1.logger.error('Failed to load me routes:', error);
}
try {
    const reportRoutes = require('./routes/reportRoutes').default;
    if (!reportRoutes) {
        logger_1.logger.error('report routes is undefined - check export');
    }
    else {
        app.use('/api/reports', reportRoutes);
        logger_1.logger.info('Report routes loaded');
    }
}
catch (error) {
    logger_1.logger.error('Failed to load report routes:', error);
}
try {
    const notificationRoutes = require('./routes/notificationRoutes').default;
    if (!notificationRoutes) {
        logger_1.logger.error('notification routes is undefined - check export');
    }
    else {
        app.use('/api/notifications', notificationRoutes);
        logger_1.logger.info('Notification routes loaded');
    }
}
catch (error) {
    logger_1.logger.error('Failed to load notification routes:', error);
}
try {
    const feedbackRoutes = require('./routes/feedbackRoutes').default;
    if (!feedbackRoutes) {
        logger_1.logger.error('feedback routes is undefined - check export');
    }
    else {
        app.use('/api', feedbackRoutes);
        logger_1.logger.info('Feedback routes loaded');
    }
}
catch (error) {
    logger_1.logger.error('Failed to load feedback routes:', error);
}
app.use((err, req, res, next) => {
    logger_1.logger.error('Global error:', err);
    console.error('🔥 DETAILED ERROR:', {
        message: err.message,
        stack: err.stack,
        code: err.code,
        meta: err.meta,
        name: err.name
    });
    res.status(500).json({
        success: false,
        message: err.message || 'Internal server error',
        error_details: process.env.NODE_ENV === 'development' ? {
            stack: err.stack,
            code: err.code,
            meta: err.meta
        } : undefined
    });
});
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        message: 'Route not found'
    });
});
async function startServer() {
    try {
        await database_1.prisma.$connect();
        logger_1.logger.info('Database connected successfully');
        logger_1.logger.info('💬 Socket.IO enabled');
        server.listen(Number(PORT), '0.0.0.0', () => {
            logger_1.logger.info(`Server is running on port ${PORT}`);
            console.log(`🚀 Server is running on http://localhost:${PORT}`);
            console.log(`📚 Health check: http://localhost:${PORT}/health`);
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to start server:', error);
        process.exit(1);
    }
}
startServer();
exports.default = app;
