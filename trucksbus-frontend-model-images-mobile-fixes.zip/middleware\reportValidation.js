"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleValidationErrors = exports.validateAdminUpdate = exports.validateCreateReport = exports.sanitizeInput = void 0;
const express_validator_1 = require("express-validator");
const sanitizeInput = (req, res, next) => {
    if (req.body) {
        for (const key in req.body) {
            if (typeof req.body[key] === 'string') {
                req.body[key] = req.body[key]
                    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                    .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '')
                    .replace(/javascript:/gi, '')
                    .replace(/on\w+\s*=/gi, '')
                    .trim();
            }
        }
    }
    next();
};
exports.sanitizeInput = sanitizeInput;
exports.validateCreateReport = [
    (0, express_validator_1.body)('listingId')
        .isString()
        .notEmpty()
        .withMessage('İlan ID gereklidir')
        .isLength({ max: 50 })
        .withMessage('İlan ID çok uzun'),
    (0, express_validator_1.body)('reasonCode')
        .isIn(['FRAUD', 'NUDITY', 'WRONG_CATEGORY', 'MISLEADING_INFO', 'COPYRIGHT', 'OTHER'])
        .withMessage('Geçerli bir sebep seçin'),
    (0, express_validator_1.body)('description')
        .isString()
        .notEmpty()
        .withMessage('Açıklama gereklidir')
        .isLength({ min: 10, max: 500 })
        .withMessage('Açıklama 10-500 karakter olmalıdır')
        .matches(/^[^<>]*$/)
        .withMessage('Açıklama geçersiz karakterler içeriyor'),
];
exports.validateAdminUpdate = [
    (0, express_validator_1.body)('status')
        .isIn(['OPEN', 'UNDER_REVIEW', 'ACCEPTED', 'REJECTED'])
        .withMessage('Geçerli bir durum seçin'),
    (0, express_validator_1.body)('resolutionNote')
        .optional()
        .isString()
        .isLength({ max: 500 })
        .withMessage('Çözüm notu 500 karakterden kısa olmalıdır'),
    (0, express_validator_1.body)('removeListing')
        .optional()
        .isBoolean()
        .withMessage('İlan kaldırma seçeneği boolean olmalıdır'),
];
const handleValidationErrors = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        res.status(400).json({
            success: false,
            message: 'Girdi doğrulama hatası',
            errors: errors.array().map(error => ({
                field: error.type === 'field' ? error.path : 'unknown',
                message: error.msg,
            })),
        });
        return;
    }
    next();
};
exports.handleValidationErrors = handleValidationErrors;
