"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationsController = void 0;
const client_1 = require("@prisma/client");
const ulid_1 = require("ulid");
const prisma = new client_1.PrismaClient();
class ConversationsController {
    static async getUserConversations(req, res) {
        try {
            const userId = req.user?.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            const rawConversations = await prisma.conversations.findMany({
                where: {
                    OR: [
                        { least_user_id: userId },
                        { greatest_user_id: userId }
                    ],
                    NOT: {
                        conversation_hidden: {
                            some: {
                                user_id: userId
                            }
                        }
                    }
                },
                take: 20,
                orderBy: { created_at: 'desc' }
            });
            const conversations = [];
            for (const conv of rawConversations) {
                const otherParticipantId = conv.least_user_id === userId
                    ? conv.greatest_user_id
                    : conv.least_user_id;
                const otherParticipant = await prisma.users.findUnique({
                    where: { id: otherParticipantId },
                    select: {
                        id: true,
                        first_name: true,
                        last_name: true,
                        username: true
                    }
                });
                let listing = null;
                if (conv.listing_id) {
                    listing = await prisma.listings.findUnique({
                        where: { id: conv.listing_id },
                        select: {
                            id: true,
                            title: true,
                            price: true,
                            images: true
                        }
                    });
                }
                const lastMessage = await prisma.messages.findFirst({
                    where: { conversation_id: conv.id },
                    orderBy: { created_at: 'desc' },
                    select: {
                        id: true,
                        body: true,
                        created_at: true,
                        sender_id: true
                    }
                });
                const unreadCounter = await prisma.conversation_unread_counters.findUnique({
                    where: {
                        conversation_id_user_id: {
                            conversation_id: conv.id,
                            user_id: userId
                        }
                    },
                    select: { unread_count: true }
                });
                const processedConversation = {
                    id: conv.id,
                    least_user_id: conv.least_user_id,
                    greatest_user_id: conv.greatest_user_id,
                    listing_id: conv.listing_id,
                    created_at: conv.created_at,
                    otherParticipant: otherParticipant ? {
                        id: otherParticipant.id,
                        first_name: otherParticipant.first_name,
                        last_name: otherParticipant.last_name,
                        username: otherParticipant.username
                    } : null,
                    listing: listing,
                    lastMessage: lastMessage ? {
                        content: lastMessage.body,
                        created_at: lastMessage.created_at,
                        sender_id: lastMessage.sender_id,
                        sender_name: lastMessage.sender_id === userId ? 'Sen' :
                            (otherParticipant ? `${otherParticipant.first_name} ${otherParticipant.last_name}` : 'Bilinmeyen')
                    } : null,
                    unreadCount: unreadCounter?.unread_count || 0
                };
                conversations.push(processedConversation);
            }
            return res.json({
                success: true,
                conversations: conversations
            });
        }
        catch (error) {
            console.error('Error getting conversations:', error);
            return res.status(500).json({
                success: false,
                message: 'Server error'
            });
        }
    }
    static async getConversationMessages(req, res) {
        try {
            const userId = req.user?.id;
            const conversationId = req.params.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            const messages = await prisma.messages.findMany({
                where: {
                    conversation_id: conversationId
                },
                orderBy: { created_at: 'asc' },
                take: 100,
                include: {
                    users: {
                        select: {
                            first_name: true,
                            last_name: true
                        }
                    }
                }
            });
            const formattedMessages = messages.map((message) => ({
                id: message.id,
                conversation_id: message.conversation_id,
                sender_id: message.sender_id,
                content: message.body,
                created_at: message.created_at,
                users: message.users
            }));
            return res.json({
                success: true,
                messages: formattedMessages
            });
        }
        catch (error) {
            console.error('Error getting messages:', error);
            return res.status(500).json({
                success: false,
                message: 'Server error'
            });
        }
    }
    static async sendMessage(req, res) {
        try {
            const userId = req.user?.id;
            const conversationId = req.params.id;
            const { content } = req.body;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            if (!content) {
                return res.status(400).json({ success: false, message: 'Message content required' });
            }
            console.log(`📤 Sending message from user ${userId} to conversation ${conversationId}`);
            const conv = await prisma.conversations.findUnique({
                where: { id: conversationId }
            });
            if (!conv) {
                return res.status(404).json({ success: false, message: 'Conversation not found' });
            }
            const isParticipant = [conv.least_user_id, conv.greatest_user_id].includes(userId);
            if (!isParticipant) {
                return res.status(403).json({ success: false, message: 'Not a participant' });
            }
            const receiverIds = [conv.least_user_id, conv.greatest_user_id].filter(id => id !== userId);
            const result = await prisma.$transaction(async (tx) => {
                if (receiverIds.length) {
                    await tx.conversation_hidden.deleteMany({
                        where: {
                            conversation_id: conversationId,
                            user_id: { in: receiverIds }
                        }
                    });
                }
                const message = await tx.messages.create({
                    data: {
                        id: (0, ulid_1.ulid)(),
                        conversation_id: conversationId,
                        sender_id: userId,
                        body: content,
                        status: 'SENT'
                    }
                });
                for (const receiverId of receiverIds) {
                    await tx.conversation_unread_counters.upsert({
                        where: {
                            conversation_id_user_id: {
                                conversation_id: conversationId,
                                user_id: receiverId
                            }
                        },
                        create: {
                            id: (0, ulid_1.ulid)(),
                            conversation_id: conversationId,
                            user_id: receiverId,
                            unread_count: 1
                        },
                        update: {
                            unread_count: { increment: 1 },
                            updated_at: new Date()
                        }
                    });
                }
                for (const receiverId of receiverIds) {
                    const total = await tx.conversation_unread_counters.aggregate({
                        _sum: { unread_count: true },
                        where: { user_id: receiverId }
                    });
                    const sum = total._sum.unread_count || 0;
                    await tx.user_unread_counters.upsert({
                        where: { user_id: receiverId },
                        create: { user_id: receiverId, total_unread: sum },
                        update: { total_unread: sum, updated_at: new Date() }
                    });
                }
                return { message };
            });
            const socketService = req.app.get('socketService');
            if (socketService) {
                const formattedMessage = {
                    id: result.message.id,
                    conversation_id: result.message.conversation_id,
                    sender_id: result.message.sender_id,
                    content: result.message.body,
                    created_at: result.message.created_at
                };
                socketService.getIO()
                    .to(`conversation:${conversationId}`)
                    .emit('message:new', { conversation_id: conversationId, message: formattedMessage });
                for (const receiverId of receiverIds) {
                    const total = await prisma.user_unread_counters.findUnique({
                        where: { user_id: receiverId }
                    });
                    socketService.getIO()
                        .to(`user:${receiverId}`)
                        .emit('badge:update', { total_unread: total?.total_unread || 0 });
                    socketService.getIO()
                        .to(`user:${receiverId}`)
                        .emit('conversation:upsert', {
                        id: conversationId,
                        lastMessage: {
                            content: formattedMessage.content,
                            created_at: formattedMessage.created_at,
                            sender_id: formattedMessage.sender_id,
                        }
                    });
                }
            }
            return res.json({
                success: true,
                message: {
                    id: result.message.id,
                    conversation_id: result.message.conversation_id,
                    sender_id: result.message.sender_id,
                    content: result.message.body,
                    created_at: result.message.created_at
                }
            });
        }
        catch (error) {
            console.error('Error sending message:', error);
            return res.status(500).json({
                success: false,
                message: 'Server error'
            });
        }
    }
    static async createConversation(req, res) {
        try {
            const userId = req.user?.id;
            const { receiverId, listingId } = req.body;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            const conversation = await prisma.conversations.create({
                data: {
                    id: (0, ulid_1.ulid)(),
                    least_user_id: userId < receiverId ? userId : receiverId,
                    greatest_user_id: userId > receiverId ? userId : receiverId,
                    listing_id: listingId || null
                }
            });
            return res.json({
                success: true,
                data: conversation
            });
        }
        catch (error) {
            console.error('Error creating conversation:', error);
            return res.status(500).json({
                success: false,
                message: 'Server error'
            });
        }
    }
    static async createOrGetConversation(req, res) {
        return ConversationsController.createConversation(req, res);
    }
    static async createConversationFromListing(req, res) {
        try {
            const userId = req.user?.id;
            const { listingId } = req.body;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            if (!listingId) {
                return res.status(400).json({
                    success: false,
                    message: 'listingId is required'
                });
            }
            const listing = await prisma.listings.findUnique({
                where: { id: listingId }
            });
            if (!listing) {
                return res.status(404).json({
                    success: false,
                    message: 'Listing not found'
                });
            }
            const receiverId = listing.user_id;
            if (userId === receiverId) {
                return res.status(400).json({
                    success: false,
                    message: 'Cannot message your own listing'
                });
            }
            const leastUserId = userId < receiverId ? userId : receiverId;
            const greatestUserId = userId < receiverId ? receiverId : userId;
            let conversation = await prisma.conversations.findFirst({
                where: {
                    least_user_id: leastUserId,
                    greatest_user_id: greatestUserId
                }
            });
            if (!conversation) {
                conversation = await prisma.conversations.create({
                    data: {
                        id: (0, ulid_1.ulid)(),
                        least_user_id: leastUserId,
                        greatest_user_id: greatestUserId,
                        listing_id: listingId
                    }
                });
            }
            return res.json({
                success: true,
                conversation: conversation
            });
        }
        catch (error) {
            console.error('Error creating conversation from listing:', error);
            return res.status(500).json({
                success: false,
                message: 'Server error'
            });
        }
    }
    static async markAsRead(req, res) {
        try {
            const userId = req.user?.id;
            const conversationId = req.params.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            if (!conversationId) {
                return res.status(400).json({ success: false, message: 'Conversation ID required' });
            }
            await prisma.conversation_unread_counters.upsert({
                where: {
                    conversation_id_user_id: {
                        conversation_id: conversationId,
                        user_id: userId
                    }
                },
                create: {
                    id: (0, ulid_1.ulid)(),
                    conversation_id: conversationId,
                    user_id: userId,
                    unread_count: 0
                },
                update: {
                    unread_count: 0,
                    updated_at: new Date()
                }
            });
            const totalAgg = await prisma.conversation_unread_counters.aggregate({
                _sum: { unread_count: true },
                where: { user_id: userId }
            });
            const sum = totalAgg._sum.unread_count || 0;
            await prisma.user_unread_counters.upsert({
                where: { user_id: userId },
                create: { user_id: userId, total_unread: sum },
                update: { total_unread: sum, updated_at: new Date() }
            });
            const socketService = req.app.get('socketService');
            if (socketService) {
                socketService.getIO()
                    .to(`user:${userId}`)
                    .emit('badge:update', { total_unread: sum });
            }
            return res.json({ success: true, message: 'Read status updated' });
        }
        catch (error) {
            console.error('Error marking as read:', error);
            return res.status(500).json({
                success: false,
                message: 'Failed to mark as read'
            });
        }
    }
    static async getUnreadCount(req, res) {
        try {
            const userId = req.user?.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            const userUnreadCounter = await prisma.user_unread_counters.findUnique({
                where: { user_id: userId },
                select: { total_unread: true }
            });
            const totalUnread = userUnreadCounter?.total_unread || 0;
            return res.json({
                success: true,
                data: { count: totalUnread }
            });
        }
        catch (error) {
            console.error('Error getting unread count:', error);
            return res.status(500).json({
                success: false,
                message: 'Failed to get unread count'
            });
        }
    }
    static async deleteConversation(req, res) {
        try {
            const userId = req.user?.id;
            const conversationId = req.params.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            if (!conversationId) {
                return res.status(400).json({ success: false, message: 'Conversation ID required' });
            }
            const conversation = await prisma.conversations.findFirst({
                where: {
                    id: conversationId,
                    OR: [
                        { least_user_id: userId },
                        { greatest_user_id: userId }
                    ]
                }
            });
            if (!conversation) {
                return res.status(404).json({ success: false, message: 'Conversation not found' });
            }
            await prisma.conversation_hidden.upsert({
                where: {
                    conversation_id_user_id: {
                        conversation_id: conversationId,
                        user_id: userId
                    }
                },
                update: {
                    hidden_at: new Date()
                },
                create: {
                    id: (0, ulid_1.ulid)(),
                    conversation_id: conversationId,
                    user_id: userId,
                    hidden_at: new Date()
                }
            });
            await prisma.conversation_unread_counters.upsert({
                where: {
                    conversation_id_user_id: {
                        conversation_id: conversationId,
                        user_id: userId
                    }
                },
                create: {
                    id: (0, ulid_1.ulid)(),
                    conversation_id: conversationId,
                    user_id: userId,
                    unread_count: 0
                },
                update: {
                    unread_count: 0,
                    updated_at: new Date()
                }
            });
            const totalAgg = await prisma.conversation_unread_counters.aggregate({
                _sum: { unread_count: true },
                where: { user_id: userId }
            });
            const sum = totalAgg._sum.unread_count || 0;
            await prisma.user_unread_counters.upsert({
                where: { user_id: userId },
                create: { user_id: userId, total_unread: sum },
                update: { total_unread: sum, updated_at: new Date() }
            });
            const socketService = req.app.get('socketService');
            if (socketService) {
                socketService.getIO()
                    .to(`user:${userId}`)
                    .emit('badge:update', { total_unread: sum });
            }
            return res.json({
                success: true,
                message: 'Conversation hidden successfully'
            });
        }
        catch (error) {
            console.error('Error hiding conversation:', error);
            return res.status(500).json({
                success: false,
                message: 'Failed to hide conversation'
            });
        }
    }
}
exports.ConversationsController = ConversationsController;
exports.default = ConversationsController;
