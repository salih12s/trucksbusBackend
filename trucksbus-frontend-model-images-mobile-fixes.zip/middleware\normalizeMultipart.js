"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeMultipartAndCoerce = normalizeMultipartAndCoerce;
const digitsOnly = (s) => String(s ?? '').replace(/\D/g, '');
function normalizeMultipartAndCoerce(req, _res, next) {
    const ct = req.headers['content-type'] || '';
    const isMultipart = ct.includes('multipart/form-data');
    console.log('🔍 CT:', ct);
    console.log('🔑 BODY KEYS:', Object.keys(req.body));
    if (isMultipart) {
        if (typeof req.body.properties === 'string') {
            try {
                req.body.properties = JSON.parse(req.body.properties);
            }
            catch {
                req.body.properties = {};
            }
        }
    }
    const numKeys = [
        'price', 'year', 'km',
        'brand_id', 'model_id', 'variant_id',
        'city_id', 'district_id'
    ];
    numKeys.forEach((k) => {
        if (req.body[k] !== undefined && req.body[k] !== null && req.body[k] !== '') {
            if (k === 'price') {
                const d = digitsOnly(req.body[k]);
                req.body[k] = d ? Number(d) : undefined;
            }
            else {
                const n = Number(req.body[k]);
                req.body[k] = Number.isFinite(n) ? n : undefined;
            }
        }
    });
    console.log('✅ Normalized body:', {
        title: req.body.title,
        price: req.body.price,
        category_id: req.body.category_id,
        vehicle_type_id: req.body.vehicle_type_id,
        price_type: typeof req.body.price,
        category_id_type: typeof req.body.category_id,
        vehicle_type_id_type: typeof req.body.vehicle_type_id
    });
    next();
}
