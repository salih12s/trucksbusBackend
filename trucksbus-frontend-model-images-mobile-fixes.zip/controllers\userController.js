"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const client_1 = require("@prisma/client");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const prisma = new client_1.PrismaClient();
class UserController {
    static async getProfile(req, res) {
        try {
            const userId = req.user?.id;
            if (!userId) {
                return res.status(401).json({ error: 'Unauthorized' });
            }
            const user = await prisma.users.findUnique({
                where: {
                    id: userId,
                },
                select: {
                    id: true,
                    first_name: true,
                    last_name: true,
                    email: true,
                    phone: true,
                    role: true,
                    created_at: true,
                    avatar: true,
                },
            });
            if (!user) {
                return res.status(404).json({ error: 'User not found' });
            }
            return res.json(user);
        }
        catch (error) {
            console.error('Get profile error:', error);
            return res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async updateProfile(req, res) {
        try {
            const userId = req.user?.id;
            const { phone, avatar } = req.body;
            if (!userId) {
                return res.status(401).json({ error: 'Unauthorized' });
            }
            const updateData = {};
            if (phone !== undefined)
                updateData.phone = phone || null;
            if (avatar !== undefined)
                updateData.avatar = avatar || null;
            const updatedUser = await prisma.users.update({
                where: {
                    id: userId,
                },
                data: updateData,
                select: {
                    id: true,
                    first_name: true,
                    last_name: true,
                    email: true,
                    phone: true,
                    role: true,
                    avatar: true,
                },
            });
            return res.json(updatedUser);
        }
        catch (error) {
            console.error('Update profile error:', error);
            return res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async getStats(req, res) {
        try {
            const userId = req.user?.id;
            if (!userId) {
                return res.status(401).json({ error: 'Unauthorized' });
            }
            const totalListings = await prisma.listings.count({
                where: {
                    user_id: userId,
                },
            });
            const activeListings = await prisma.listings.count({
                where: {
                    user_id: userId,
                    is_approved: true,
                },
            });
            const user = await prisma.users.findUnique({
                where: {
                    id: userId,
                },
                select: {
                    created_at: true,
                },
            });
            return res.json({
                totalListings,
                activeListings,
                totalViews: 0,
                joinDate: user?.created_at || new Date(),
            });
        }
        catch (error) {
            console.error('Get stats error:', error);
            return res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async changePassword(req, res) {
        try {
            const userId = req.user?.id;
            const { currentPassword, newPassword } = req.body;
            if (!userId) {
                return res.status(401).json({ error: 'Unauthorized' });
            }
            if (!currentPassword || !newPassword) {
                return res.status(400).json({ error: 'Current password and new password are required' });
            }
            const user = await prisma.users.findUnique({
                where: { id: userId },
                select: { id: true, password: true }
            });
            if (!user || !user.password) {
                return res.status(404).json({ error: 'User not found or invalid password' });
            }
            const isCurrentPasswordValid = await bcryptjs_1.default.compare(currentPassword, user.password);
            if (!isCurrentPasswordValid) {
                return res.status(400).json({ error: 'Current password is incorrect' });
            }
            const hashedNewPassword = await bcryptjs_1.default.hash(newPassword, 10);
            await prisma.users.update({
                where: { id: userId },
                data: { password: hashedNewPassword }
            });
            return res.json({ message: 'Password changed successfully' });
        }
        catch (error) {
            console.error('Change password error:', error);
            return res.status(500).json({ error: 'Internal server error' });
        }
    }
}
exports.UserController = UserController;
