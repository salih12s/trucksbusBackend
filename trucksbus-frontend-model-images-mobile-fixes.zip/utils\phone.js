"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isValidMobilePhoneTR = exports.formatPhoneTR = exports.isValidPhoneTR = exports.normalizePhoneTR = exports.digitsOnly = void 0;
const digitsOnly = (s) => (s || '').replace(/\D/g, '');
exports.digitsOnly = digitsOnly;
const normalizePhoneTR = (raw) => {
    const d = (0, exports.digitsOnly)(raw);
    if (d.length === 11 && d.startsWith('0')) {
        return d;
    }
    if (d.length === 10 && d.startsWith('5')) {
        return '0' + d;
    }
    return '';
};
exports.normalizePhoneTR = normalizePhoneTR;
const isValidPhoneTR = (raw) => {
    return !!(0, exports.normalizePhoneTR)(raw);
};
exports.isValidPhoneTR = isValidPhoneTR;
const formatPhoneTR = (raw) => {
    const d = (0, exports.normalizePhoneTR)(raw);
    if (!d)
        return '';
    return `${d.slice(0, 4)} ${d.slice(4, 7)} ${d.slice(7, 9)} ${d.slice(9, 11)}`;
};
exports.formatPhoneTR = formatPhoneTR;
const isValidMobilePhoneTR = (raw) => {
    const normalized = (0, exports.normalizePhoneTR)(raw);
    return normalized.length === 11 && normalized.startsWith('05');
};
exports.isValidMobilePhoneTR = isValidMobilePhoneTR;
