"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationService = void 0;
const prisma_1 = require("../utils/prisma");
const socket_1 = require("../utils/socket");
class NotificationService {
    static async createReportNotification(userId, type, title, message, data) {
        try {
            const notification = await prisma_1.prisma.notifications.create({
                data: {
                    id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                    user_id: userId,
                    type,
                    title,
                    message,
                    data: data ? data : undefined,
                },
            });
            await prisma_1.prisma.user_unread_counters.upsert({
                where: { user_id: userId },
                update: {
                    total_unread: { increment: 1 },
                    updated_at: new Date(),
                },
                create: {
                    user_id: userId,
                    total_unread: 1,
                },
            });
            const io = (0, socket_1.getIO)();
            io.to(`user:${userId}`).emit('notification', {
                ...notification,
                data: data || null,
            });
            const counter = await prisma_1.prisma.user_unread_counters.findUnique({
                where: { user_id: userId },
            });
            io.to(`user:${userId}`).emit('unreadCountUpdate', {
                total_unread: counter?.total_unread || 0,
            });
            return notification;
        }
        catch (error) {
            console.error('Error creating notification:', error);
            throw error;
        }
    }
    static async markAsRead(notificationIds, userId) {
        try {
            const result = await prisma_1.prisma.notifications.updateMany({
                where: {
                    id: { in: notificationIds },
                    user_id: userId,
                    is_read: false,
                },
                data: { is_read: true },
            });
            await prisma_1.prisma.user_unread_counters.update({
                where: { user_id: userId },
                data: {
                    total_unread: { decrement: result.count },
                    updated_at: new Date(),
                },
            });
            const io = (0, socket_1.getIO)();
            const counter = await prisma_1.prisma.user_unread_counters.findUnique({
                where: { user_id: userId },
            });
            io.to(`user:${userId}`).emit('unreadCountUpdate', {
                total_unread: Math.max(0, counter?.total_unread || 0),
            });
            return result;
        }
        catch (error) {
            console.error('Error marking notifications as read:', error);
            throw error;
        }
    }
    static async getUserNotifications(userId, isRead) {
        return prisma_1.prisma.notifications.findMany({
            where: {
                user_id: userId,
                ...(isRead !== undefined && { is_read: isRead }),
            },
            orderBy: { created_at: 'desc' },
        });
    }
    static async getUnreadCount(userId) {
        const counter = await prisma_1.prisma.user_unread_counters.findUnique({
            where: { user_id: userId },
        });
        return counter?.total_unread || 0;
    }
}
exports.NotificationService = NotificationService;
