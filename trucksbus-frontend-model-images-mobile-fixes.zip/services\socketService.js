"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocketService = void 0;
const socket_io_1 = require("socket.io");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const client_1 = require("@prisma/client");
const ulid_1 = require("ulid");
const logger_1 = require("../utils/logger");
const prisma = new client_1.PrismaClient();
class SocketService {
    constructor(server) {
        this.connectedUsers = new Map();
        this.io = new socket_io_1.Server(server, {
            cors: {
                origin: ["http://localhost:5173"],
                credentials: true
            }
        });
        this.setupMiddleware();
        this.setupEventHandlers();
        logger_1.logger.info('Socket.IO service initialized');
    }
    async isParticipant(userId, conversationId) {
        try {
            const conv = await prisma.conversations.findUnique({
                where: { id: conversationId },
                select: { least_user_id: true, greatest_user_id: true }
            });
            if (!conv)
                return false;
            return conv.least_user_id === userId || conv.greatest_user_id === userId;
        }
        catch (error) {
            logger_1.logger.error('Error checking participant status:', error);
            return false;
        }
    }
    async createAndBroadcastMessage(conversation_id, senderId, body) {
        const conv = await prisma.conversations.findUnique({ where: { id: conversation_id } });
        if (!conv)
            throw new Error('Conversation not found');
        if (![conv.least_user_id, conv.greatest_user_id].includes(senderId)) {
            throw new Error('Not a participant');
        }
        const message = await prisma.messages.create({
            data: {
                id: (0, ulid_1.ulid)(),
                conversation_id,
                sender_id: senderId,
                body,
                status: 'SENT'
            }
        });
        const senderInfo = await prisma.users.findUnique({
            where: { id: senderId },
            select: {
                id: true,
                first_name: true,
                last_name: true,
                username: true
            }
        });
        const completeMessage = {
            id: message.id,
            conversation_id,
            sender_id: senderId,
            content: message.body,
            created_at: message.created_at,
            users: senderInfo
        };
        this.io.to(`conversation:${conversation_id}`).emit('message:new', {
            conversation_id,
            message: completeMessage
        });
        const receiverIds = [conv.least_user_id, conv.greatest_user_id].filter((id) => id !== senderId);
        for (const receiverId of receiverIds) {
            await prisma.conversation_unread_counters.upsert({
                where: {
                    conversation_id_user_id: {
                        conversation_id,
                        user_id: receiverId
                    }
                },
                create: {
                    id: (0, ulid_1.ulid)(),
                    conversation_id,
                    user_id: receiverId,
                    unread_count: 1
                },
                update: {
                    unread_count: { increment: 1 },
                    updated_at: new Date()
                }
            });
            const totalAgg = await prisma.conversation_unread_counters.aggregate({
                _sum: { unread_count: true },
                where: { user_id: receiverId }
            });
            const totalUnread = totalAgg._sum.unread_count || 0;
            await prisma.user_unread_counters.upsert({
                where: { user_id: receiverId },
                create: { user_id: receiverId, total_unread: totalUnread },
                update: { total_unread: totalUnread, updated_at: new Date() }
            });
            this.io.to(`user:${receiverId}`).emit('badge:update', { total_unread: totalUnread });
        }
        return completeMessage;
    }
    setupMiddleware() {
        this.io.use(async (socket, next) => {
            try {
                const token = socket.handshake.auth?.token;
                if (!token) {
                    return next(new Error('NO_TOKEN'));
                }
                const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET || 'your-secret-key');
                socket.userId = decoded.id;
                logger_1.logger.info(`Socket authenticated for user: ${decoded.id}`);
                next();
            }
            catch (error) {
                logger_1.logger.error('Socket authentication failed:', error);
                next(new Error('BAD_TOKEN'));
            }
        });
    }
    setupEventHandlers() {
        this.io.on('connection', (socket) => {
            const userId = socket.userId;
            if (!userId) {
                socket.disconnect();
                return;
            }
            this.connectedUsers.set(userId, socket.id);
            logger_1.logger.info(`User ${userId} connected with socket ${socket.id}`);
            socket.join(`user:${userId}`);
            logger_1.logger.info(`User ${userId} connected with socket ${socket.id}`);
            socket.on('conversation:join', async ({ conversation_id }) => {
                try {
                    if (!conversation_id)
                        return;
                    const ok = await this.isParticipant(userId, conversation_id);
                    if (!ok) {
                        logger_1.logger.warn(`🚫 Forbidden join attempt by ${userId} to ${conversation_id}`);
                        socket.emit('error:forbidden', { resource: 'conversation', id: conversation_id });
                        return;
                    }
                    socket.join(`conversation:${conversation_id}`);
                    logger_1.logger.info(`✅ User ${userId} joined conversation: ${conversation_id}`);
                }
                catch (error) {
                    logger_1.logger.error('join error:', error);
                }
            });
            socket.on('join_conversation', async (conversationId) => {
                try {
                    if (!conversationId)
                        return;
                    const ok = await this.isParticipant(userId, conversationId);
                    if (!ok) {
                        logger_1.logger.warn(`🚫 Forbidden legacy join attempt by ${userId} to ${conversationId}`);
                        socket.emit('error:forbidden', { resource: 'conversation', id: conversationId });
                        return;
                    }
                    socket.join(`conversation:${conversationId}`);
                    logger_1.logger.info(`✅ User ${userId} joined conversation (legacy): ${conversationId}`);
                }
                catch (error) {
                    logger_1.logger.error('legacy join error:', error);
                }
            });
            socket.on('conversation:leave', async ({ conversation_id }) => {
                try {
                    if (!conversation_id)
                        return;
                    const ok = await this.isParticipant(userId, conversation_id);
                    if (!ok)
                        return;
                    socket.leave(`conversation:${conversation_id}`);
                    logger_1.logger.info(`👋 User ${userId} left conversation: ${conversation_id}`);
                }
                catch (error) {
                    logger_1.logger.error('leave error:', error);
                }
            });
            socket.on('leave_conversation', async (conversationId) => {
                try {
                    if (!conversationId)
                        return;
                    const ok = await this.isParticipant(userId, conversationId);
                    if (!ok)
                        return;
                    socket.leave(`conversation:${conversationId}`);
                    logger_1.logger.info(`👋 User ${userId} left conversation (legacy): ${conversationId}`);
                }
                catch (error) {
                    logger_1.logger.error('legacy leave error:', error);
                }
            });
            socket.on('typing_start', (data) => {
                const convId = data.conversationId || data.conversation_id;
                if (!convId)
                    return;
                socket.to(`conversation:${convId}`).emit('user_typing', {
                    userId: userId,
                    typing: true
                });
            });
            socket.on('typing_stop', (data) => {
                const convId = data.conversationId || data.conversation_id;
                if (!convId)
                    return;
                socket.to(`conversation:${convId}`).emit('user_typing', {
                    userId: userId,
                    typing: false
                });
            });
            socket.on('message:send', async (payload, cb) => {
                try {
                    const res = await this.createAndBroadcastMessage(payload.conversation_id, userId, payload.body);
                    cb?.({ ok: true, message: res });
                }
                catch (err) {
                    logger_1.logger.error('message:send error:', err);
                    cb?.({ ok: false, error: err?.message || 'Failed to send' });
                }
            });
            socket.on('send_message', async (payload, cb) => {
                try {
                    const messageBody = payload.content || payload.body || '';
                    const res = await this.createAndBroadcastMessage(payload.conversationId, userId, messageBody);
                    cb?.({ ok: true, message: res });
                }
                catch (err) {
                    logger_1.logger.error('send_message error:', err);
                    cb?.({ ok: false, error: err?.message || 'Failed to send' });
                }
            });
            socket.on('disconnect', () => {
                if (userId) {
                    this.connectedUsers.delete(userId);
                    logger_1.logger.info(`User ${userId} disconnected`);
                }
            });
        });
    }
    emitNewMessage(conversationId, message) {
        logger_1.logger.info(`Emitting new message to conversation: ${conversationId}`, message);
        this.io.to(`conversation:${conversationId}`).emit('message:new', {
            conversation_id: conversationId,
            message
        });
    }
    emitBadgeUpdate(userId, totalUnread) {
        logger_1.logger.info(`Emitting badge update to user: ${userId}, total: ${totalUnread}`);
        this.io.to(`user:${userId}`).emit('badge:update', { total_unread: totalUnread });
    }
    emitMessageStatus(conversationId, messageId, status) {
        this.io.to(`conversation:${conversationId}`).emit('message_status_update', {
            messageId,
            status
        });
    }
    isUserOnline(userId) {
        return this.connectedUsers.has(userId);
    }
    getIO() {
        return this.io;
    }
    async sendNotificationToUser(userId, notification) {
        const userSocketId = this.connectedUsers.get(userId);
        if (userSocketId) {
            this.io.to(userSocketId).emit('notification', notification);
        }
    }
    async sendNotificationToAdmins(notification) {
        for (const [userId, socketId] of this.connectedUsers.entries()) {
            try {
                const user = await prisma.users.findUnique({
                    where: { id: userId },
                    select: { role: true }
                });
                if (user && user.role === 'ADMIN') {
                    this.io.to(socketId).emit('notification', notification);
                }
            }
            catch (error) {
                logger_1.logger.error('Error checking user role for notification:', error);
            }
        }
    }
    broadcastFeedbackUpdate(feedbackId, status) {
        this.io.emit('feedback_status_update', {
            feedbackId,
            status
        });
    }
}
exports.SocketService = SocketService;
