"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.safeStringify = exports.toBool = void 0;
exports.normalizeFeatures = normalizeFeatures;
function normalizeFeatures(input) {
    if (input == null)
        return {};
    if (typeof input === 'string') {
        try {
            const parsed = JSON.parse(input);
            return (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) ? parsed : {};
        }
        catch {
            return {};
        }
    }
    if (typeof input === 'object' && !Array.isArray(input)) {
        return input;
    }
    return {};
}
const toBool = (v) => {
    return v === true || v === 1 || v === '1' || v === 'true';
};
exports.toBool = toBool;
const safeStringify = (obj) => {
    try {
        if (obj && typeof obj === 'object') {
            return JSON.stringify(obj);
        }
        return JSON.stringify({});
    }
    catch {
        return JSON.stringify({});
    }
};
exports.safeStringify = safeStringify;
