"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationController = void 0;
const database_1 = require("../utils/database");
class NotificationController {
    static async getUnreadCount(req, res) {
        try {
            const userId = req.user?.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            const unreadCount = await database_1.prisma.notifications.count({
                where: {
                    user_id: userId,
                    is_read: false
                }
            });
            return res.json({ success: true, unreadCount });
        }
        catch (error) {
            console.error('Error getting unread count:', error);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }
    }
    static async markAsRead(req, res) {
        try {
            const userId = req.user?.id;
            const notificationId = req.params.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            await database_1.prisma.notifications.updateMany({
                where: {
                    id: notificationId,
                    user_id: userId
                },
                data: {
                    is_read: true
                }
            });
            return res.json({ success: true });
        }
        catch (error) {
            console.error('Error marking notification as read:', error);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }
    }
    static async markAllAsRead(req, res) {
        try {
            const userId = req.user?.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            await database_1.prisma.notifications.updateMany({
                where: {
                    user_id: userId,
                    is_read: false
                },
                data: {
                    is_read: true
                }
            });
            return res.json({ success: true });
        }
        catch (error) {
            console.error('Error marking all notifications as read:', error);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }
    }
    static async getNotifications(req, res) {
        try {
            const userId = req.user?.id;
            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }
            const notifications = await database_1.prisma.notifications.findMany({
                where: { user_id: userId },
                orderBy: { created_at: 'desc' },
                take: 50
            });
            return res.json({ success: true, notifications });
        }
        catch (error) {
            console.error('Error getting notifications:', error);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }
    }
}
exports.NotificationController = NotificationController;
