"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const conversationsController_1 = require("../controllers/conversationsController");
const auth_1 = require("../middleware/auth");
const requireConversationParticipant_1 = __importDefault(require("../middleware/requireConversationParticipant"));
const router = express_1.default.Router();
router.use(auth_1.authenticateToken);
router.post('/', conversationsController_1.ConversationsController.createOrGetConversation);
router.post('/from-listing', conversationsController_1.ConversationsController.createConversationFromListing);
router.get('/', conversationsController_1.ConversationsController.getUserConversations);
router.get('/:id/messages', requireConversationParticipant_1.default, conversationsController_1.ConversationsController.getConversationMessages);
router.post('/:id/messages', requireConversationParticipant_1.default, conversationsController_1.ConversationsController.sendMessage);
router.put('/:id/read', requireConversationParticipant_1.default, conversationsController_1.ConversationsController.markAsRead);
router.delete('/:id', requireConversationParticipant_1.default, conversationsController_1.ConversationsController.deleteConversation);
exports.default = router;
