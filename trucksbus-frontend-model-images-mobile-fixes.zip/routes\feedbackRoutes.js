"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const auth_1 = require("../middleware/auth");
const express_validator_1 = require("express-validator");
const feedbackController = __importStar(require("../controllers/feedbackController"));
const router = express_1.default.Router();
const ULID_RE = /^[0123456789ABCDEFGHJKMNPQRSTVWXYZ]{26}$/;
const validate = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        res.status(400).json({
            success: false,
            message: 'Validation error',
            errors: errors.array()
        });
        return;
    }
    next();
};
router.post('/feedback', auth_1.authMiddleware, [
    (0, express_validator_1.body)('subject')
        .notEmpty()
        .withMessage('Konu alanı gereklidir')
        .isLength({ max: 200 })
        .withMessage('Konu en fazla 200 karakter olabilir'),
    (0, express_validator_1.body)('message')
        .notEmpty()
        .withMessage('Mesaj alanı gereklidir')
        .isLength({ max: 2000 })
        .withMessage('Mesaj en fazla 2000 karakter olabilir'),
    (0, express_validator_1.body)('type')
        .optional()
        .isIn(['COMPLAINT', 'SUGGESTION', 'BUG_REPORT', 'FEATURE_REQUEST', 'GENERAL'])
        .withMessage('Geçersiz feedback türü'),
    (0, express_validator_1.body)('priority')
        .optional()
        .isIn(['LOW', 'MEDIUM', 'HIGH', 'URGENT'])
        .withMessage('Geçersiz öncelik seviyesi')
], validate, feedbackController.createFeedback);
router.get('/feedback/my-feedbacks', auth_1.authMiddleware, feedbackController.getUserFeedbacks);
router.get('/admin/feedback', auth_1.authMiddleware, auth_1.adminMiddleware, [
    (0, express_validator_1.query)('page').optional().isInt({ min: 1 }).withMessage('Sayfa numarası pozitif bir sayı olmalı'),
    (0, express_validator_1.query)('limit').optional().isInt({ min: 1, max: 50 }).withMessage('Limit 1-50 arasında olmalı'),
    (0, express_validator_1.query)('status').optional().isIn(['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED']).withMessage('Geçersiz durum'),
    (0, express_validator_1.query)('type').optional().isIn(['COMPLAINT', 'SUGGESTION', 'BUG_REPORT', 'FEATURE_REQUEST', 'GENERAL']).withMessage('Geçersiz tip'),
    (0, express_validator_1.query)('priority').optional().isIn(['LOW', 'MEDIUM', 'HIGH', 'URGENT']).withMessage('Geçersiz öncelik')
], validate, feedbackController.getAllFeedbacks);
router.get('/admin/feedback/stats', auth_1.authMiddleware, auth_1.adminMiddleware, feedbackController.getFeedbackStats);
router.get('/admin/feedback/:id', auth_1.authMiddleware, auth_1.adminMiddleware, [
    (0, express_validator_1.param)('id').matches(ULID_RE).withMessage('Geçersiz feedback ID')
], feedbackController.getFeedbackDetail);
router.post('/admin/feedback/:id/respond', auth_1.authMiddleware, auth_1.adminMiddleware, [
    (0, express_validator_1.param)('id').matches(ULID_RE).withMessage('Geçersiz feedback ID'),
    (0, express_validator_1.body)('response')
        .notEmpty()
        .withMessage('Yanıt mesajı gereklidir')
        .isLength({ max: 2000 })
        .withMessage('Yanıt en fazla 2000 karakter olabilir'),
    (0, express_validator_1.body)('status')
        .optional()
        .isIn(['IN_PROGRESS', 'RESOLVED', 'CLOSED'])
        .withMessage('Geçersiz durum')
], validate, feedbackController.respondToFeedback);
router.put('/admin/feedback/:id/status', auth_1.authMiddleware, auth_1.adminMiddleware, [
    (0, express_validator_1.param)('id').matches(ULID_RE).withMessage('Geçersiz feedback ID'),
    (0, express_validator_1.body)('status')
        .isIn(['PENDING', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'])
        .withMessage('Geçersiz durum')
], feedbackController.updateFeedbackStatus);
exports.default = router;
