"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireConversationParticipant = requireConversationParticipant;
const prisma_1 = require("../utils/prisma");
async function requireConversationParticipant(req, res, next) {
    try {
        const userId = req.user?.id;
        const conversationId = req.params.id || req.body.conversationId;
        if (!userId) {
            res.status(401).json({
                success: false,
                error: 'Unauthorized - authentication required'
            });
            return;
        }
        if (!conversationId) {
            res.status(400).json({
                success: false,
                error: 'Bad Request - conversation ID required'
            });
            return;
        }
        const conversation = await prisma_1.prisma.conversations.findUnique({
            where: { id: conversationId }
        });
        if (!conversation) {
            res.status(404).json({
                success: false,
                error: 'Conversation not found'
            });
            return;
        }
        const isParticipant = [conversation.least_user_id, conversation.greatest_user_id].includes(userId);
        if (!isParticipant) {
            res.status(403).json({
                success: false,
                error: 'Forbidden - not a participant in this conversation'
            });
            return;
        }
        next();
    }
    catch (error) {
        console.error('Error in requireConversationParticipant middleware:', error);
        next(error);
    }
}
exports.default = requireConversationParticipant;
